import App from "./App";
import AppSettings from "./AppSettings";

export default {
  component: App,
  settings: AppSettings,
};
