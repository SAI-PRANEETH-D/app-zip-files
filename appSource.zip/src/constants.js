export const DEFAULT_SETTINGS = {
  isExampleCheckboxChecked: false
};
